create definer = root@localhost trigger groupDirectionTrigger
    before DELETE
    on group_direction
    for each row
BEGIN
  UPDATE titles t SET t.idGroupDirection = 1 WHERE t.idGroupDirection = old.idGroupDirection;
END;

