create
    definer = root@localhost procedure creditCount(IN idTitle int)
BEGIN
SELECT COUNT(s.credits) AS 'count' FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.credits = 1) UNION ALL
  SELECT COUNT(s.credits) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.credits = 2) UNION ALL
  SELECT COUNT(s.credits) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.credits = 3) UNION ALL
  SELECT COUNT(s.credits) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.credits = 4) UNION ALL
  SELECT COUNT(s.credits) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.credits = 5) UNION ALL
SELECT COUNT(s.credits) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.credits = 6) UNION ALL
  SELECT COUNT(s.credits) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.credits = 7) UNION ALL
  SELECT COUNT(s.credits) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.credits = 8);
END;

