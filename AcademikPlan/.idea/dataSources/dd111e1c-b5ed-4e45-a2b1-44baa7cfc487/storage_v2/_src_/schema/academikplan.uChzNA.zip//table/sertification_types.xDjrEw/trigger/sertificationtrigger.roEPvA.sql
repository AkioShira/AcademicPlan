create definer = root@localhost trigger sertificationTrigger
    before DELETE
    on sertification_types
    for each row
BEGIN
  UPDATE state_sertification ss SET ss.idSertificationType = 1 WHERE ss.idSertificationType = old.idSertificationType;
END;

