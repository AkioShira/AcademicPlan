create
    definer = root@localhost procedure kpCount(IN idTitle int)
BEGIN
SELECT COUNT(s.name) AS 'count' FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE (s.name LIKE ('%Курсовой проект%') OR s.name LIKE ('%Курсовая работа%')) 
  AND c.idTitle = idTitle AND (s.exams = 1 OR s.credits = 1) UNION ALL
SELECT COUNT(s.name) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE (s.name LIKE ('%Курсовой проект%') OR s.name LIKE ('%Курсовая работа%')) 
  AND c.idTitle = idTitle AND (s.exams = 2 OR s.credits = 2) UNION ALL
  SELECT COUNT(s.name) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE (s.name LIKE ('%Курсовой проект%') OR s.name LIKE ('%Курсовая работа%')) 
  AND c.idTitle = idTitle AND (s.exams = 3 OR s.credits = 3) UNION ALL
  SELECT COUNT(s.name) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE (s.name LIKE ('%Курсовой проект%') OR s.name LIKE ('%Курсовая работа%')) 
  AND c.idTitle = idTitle AND (s.exams = 4 OR s.credits = 4) UNION ALL
  SELECT COUNT(s.name) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE (s.name LIKE ('%Курсовой проект%') OR s.name LIKE ('%Курсовая работа%')) 
  AND c.idTitle = idTitle AND (s.exams = 5 OR s.credits = 5) UNION ALL
  SELECT COUNT(s.name) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE (s.name LIKE ('%Курсовой проект%') OR s.name LIKE ('%Курсовая работа%')) 
  AND c.idTitle = idTitle AND (s.exams = 6 OR s.credits = 6) UNION ALL
  SELECT COUNT(s.name) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE (s.name LIKE ('%Курсовой проект%') OR s.name LIKE ('%Курсовая работа%')) 
  AND c.idTitle = idTitle AND (s.exams = 7 OR s.credits = 7) UNION ALL
  SELECT COUNT(s.name) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE (s.name LIKE ('%Курсовой проект%') OR s.name LIKE ('%Курсовая работа%')) 
  AND c.idTitle = idTitle AND (s.exams = 8 OR s.credits = 8);
END;

