create
    definer = root@localhost procedure examCount(IN idTitle int)
BEGIN
SELECT COUNT(s.exams) AS 'count' FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 1) UNION ALL
  SELECT COUNT(s.exams) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 2) UNION ALL
  SELECT COUNT(s.exams) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 3) UNION ALL
  SELECT COUNT(s.exams) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 4) UNION ALL
  SELECT COUNT(s.exams) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 5) UNION ALL
SELECT COUNT(s.exams) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 6) UNION ALL
  SELECT COUNT(s.exams) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 7) UNION ALL
  SELECT COUNT(s.exams) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 8);
END;

