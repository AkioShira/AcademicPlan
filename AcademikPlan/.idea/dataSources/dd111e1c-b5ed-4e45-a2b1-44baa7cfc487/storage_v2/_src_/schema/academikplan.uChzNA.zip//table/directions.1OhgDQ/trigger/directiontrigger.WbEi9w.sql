create definer = root@localhost trigger directionTrigger
    before DELETE
    on directions
    for each row
BEGIN
  UPDATE titles t SET t.idDirection = 1 WHERE t.idDirection = old.idDirection;
END;

