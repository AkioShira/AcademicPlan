create definer = root@localhost trigger practTypeTrigger
    before DELETE
    on pract_types
    for each row
BEGIN
  UPDATE practs p SET p.idPractType = 1 WHERE p.idPractType = old.idPractType;
END;

