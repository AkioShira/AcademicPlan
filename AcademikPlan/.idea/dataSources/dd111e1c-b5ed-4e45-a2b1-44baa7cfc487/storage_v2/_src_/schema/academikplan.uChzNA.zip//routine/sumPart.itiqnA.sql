create
    definer = root@localhost procedure sumPart(IN idPart int, IN studyTime int(1))
BEGIN
  
  /* Лекции */
  SELECT SUM(s.lec*9) INTO @lecLast FROM subjects s WHERE s.idPart = idPart AND (s.exams=studyTime*2 OR s.credits=studyTime*2);
  SELECT SUM(s.lec*18)+IFNULL(@lecLast, 0) INTO @lec FROM subjects s WHERE s.idPart = idPart AND (s.exams!=studyTime*2 AND s.credits!=studyTime*2);
  /* Лабораторные */
  SELECT SUM(s.lab*9) INTO @labLast FROM subjects s WHERE s.idPart = idPart AND (s.exams=studyTime*2 OR s.credits=studyTime*2);
  SELECT SUM(s.lab*18)+IFNULL(@labLast, 0) INTO @lab FROM subjects s WHERE s.idPart = idPart AND (s.exams!=studyTime*2 AND s.credits!=studyTime*2);
  /* Практики */
  SELECT SUM(s.pract*9) INTO @practLast FROM subjects s WHERE s.idPart = idPart AND (s.exams=studyTime*2 OR s.credits=studyTime*2);
  SELECT SUM(s.pract*18)+IFNULL(@practLast, 0) INTO @pract FROM subjects s WHERE s.idPart = idPart AND (s.exams!=studyTime*2 AND s.credits!=studyTime*2);
  /* КСР */
  SELECT SUM(s.self*9) INTO @selfLast FROM subjects s WHERE s.idPart = idPart AND (s.exams=studyTime*2 OR s.credits=studyTime*2);
  SELECT SUM(s.self*18)+IFNULL(@selfLast, 0) INTO @ksr FROM subjects s WHERE s.idPart = idPart AND (s.exams!=studyTime*2 AND s.credits!=studyTime*2);
  /* БСР */
  SELECT SUM(s.bsr) INTO @bsr FROM subjects s WHERE s.idPart = idPart;

  SELECT (@lec + @lab + @pract + @ksr + @bsr)/36 AS 'sum' UNION ALL
  SELECT COUNT(s.exams) FROM subjects s WHERE s.idPart = idPart AND s.exams>0 UNION ALL
  SELECT COUNT(s.credits) FROM subjects s WHERE s.idPart = idPart AND s.credits>0 UNION ALL
  SELECT @lec + @lab + @pract + @ksr + @bsr UNION ALL
  SELECT @lec + @lab + @pract UNION ALL
  SELECT @lec UNION ALL
  SELECT @lab UNION ALL
  SELECT @pract UNION ALL
  SELECT @ksr + @bsr UNION ALL
  SELECT @ksr UNION ALL
  SELECT @bsr UNION ALL

  SELECT SUM(s.lec) FROM subjects s WHERE s.idPart = idPart AND (s.exams=1 OR s.credits=1) UNION ALL
  SELECT SUM(s.lab) FROM subjects s WHERE s.idPart = idPart AND (s.exams=1 OR s.credits=1) UNION ALL
  SELECT SUM(s.pract) FROM subjects s WHERE s.idPart = idPart AND (s.exams=1 OR s.credits=1) UNION ALL
  SELECT SUM(s.self) FROM subjects s WHERE s.idPart = idPart AND (s.exams=1 OR s.credits=1) UNION ALL
  
  SELECT SUM(s.lec) FROM subjects s WHERE s.idPart = idPart AND (s.exams=2 OR s.credits=2) UNION ALL
  SELECT SUM(s.lab) FROM subjects s WHERE s.idPart = idPart AND (s.exams=2 OR s.credits=2) UNION ALL
  SELECT SUM(s.pract) FROM subjects s WHERE s.idPart = idPart AND (s.exams=2 OR s.credits=2) UNION ALL
  SELECT SUM(s.self) FROM subjects s WHERE s.idPart = idPart AND (s.exams=2 OR s.credits=2) UNION ALL
  
  SELECT SUM(s.lec) FROM subjects s WHERE s.idPart = idPart AND (s.exams=3 OR s.credits=3) UNION ALL
  SELECT SUM(s.lab) FROM subjects s WHERE s.idPart = idPart AND (s.exams=3 OR s.credits=3) UNION ALL
  SELECT SUM(s.pract) FROM subjects s WHERE s.idPart = idPart AND (s.exams=3 OR s.credits=3) UNION ALL
  SELECT SUM(s.self) FROM subjects s WHERE s.idPart = idPart AND (s.exams=3 OR s.credits=3) UNION ALL
  
  SELECT SUM(s.lec) FROM subjects s WHERE s.idPart = idPart AND (s.exams=4 OR s.credits=4) UNION ALL
  SELECT SUM(s.lab) FROM subjects s WHERE s.idPart = idPart AND (s.exams=4 OR s.credits=4) UNION ALL
  SELECT SUM(s.pract) FROM subjects s WHERE s.idPart = idPart AND (s.exams=4 OR s.credits=4) UNION ALL
  SELECT SUM(s.self) FROM subjects s WHERE s.idPart = idPart AND (s.exams=4 OR s.credits=4) UNION ALL
  
  SELECT SUM(s.lec) FROM subjects s WHERE s.idPart = idPart AND (s.exams=5 OR s.credits=5) UNION ALL
  SELECT SUM(s.lab) FROM subjects s WHERE s.idPart = idPart AND (s.exams=5 OR s.credits=5) UNION ALL
  SELECT SUM(s.pract) FROM subjects s WHERE s.idPart = idPart AND (s.exams=5 OR s.credits=5) UNION ALL
  SELECT SUM(s.self) FROM subjects s WHERE s.idPart = idPart AND (s.exams=5 OR s.credits=5) UNION ALL
  
  SELECT SUM(s.lec) FROM subjects s WHERE s.idPart = idPart AND (s.exams=6 OR s.credits=6) UNION ALL
  SELECT SUM(s.lab) FROM subjects s WHERE s.idPart = idPart AND (s.exams=6 OR s.credits=6) UNION ALL
  SELECT SUM(s.pract) FROM subjects s WHERE s.idPart = idPart AND (s.exams=6 OR s.credits=6) UNION ALL
  SELECT SUM(s.self) FROM subjects s WHERE s.idPart = idPart AND (s.exams=6 OR s.credits=6) UNION ALL
  
  SELECT SUM(s.lec) FROM subjects s WHERE s.idPart = idPart AND (s.exams=7 OR s.credits=7) UNION ALL
  SELECT SUM(s.lab) FROM subjects s WHERE s.idPart = idPart AND (s.exams=7 OR s.credits=7) UNION ALL
  SELECT SUM(s.pract) FROM subjects s WHERE s.idPart = idPart AND (s.exams=7 OR s.credits=7) UNION ALL
  SELECT SUM(s.self) FROM subjects s WHERE s.idPart = idPart AND (s.exams=7 OR s.credits=7) UNION ALL
  
  SELECT SUM(s.lec) FROM subjects s WHERE s.idPart = idPart AND (s.exams=8 OR s.credits=8) UNION ALL
  SELECT SUM(s.lab) FROM subjects s WHERE s.idPart = idPart AND (s.exams=8 OR s.credits=8) UNION ALL
  SELECT SUM(s.pract) FROM subjects s WHERE s.idPart = idPart AND (s.exams=8 OR s.credits=8) UNION ALL
  SELECT SUM(s.self) FROM subjects s WHERE s.idPart = idPart AND (s.exams=8 OR s.credits=8);
END;

