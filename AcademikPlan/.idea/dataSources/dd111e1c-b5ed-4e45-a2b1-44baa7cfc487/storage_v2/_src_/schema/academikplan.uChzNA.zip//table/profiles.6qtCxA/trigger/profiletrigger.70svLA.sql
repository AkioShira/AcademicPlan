create definer = root@localhost trigger profileTrigger
    before DELETE
    on profiles
    for each row
BEGIN
  UPDATE titles t SET t.idProfile = 1 WHERE t.idProfile = old.idProfile;
END;

