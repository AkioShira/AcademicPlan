create
    definer = root@localhost procedure sumAud(IN idTitle int)
BEGIN
SELECT SUM(s.lec+ s.lab +s.pract) AS 'sum' FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 1 OR s.credits = 1) UNION ALL
  SELECT SUM(s.lec+ s.lab +s.pract) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 2 OR s.credits = 2) UNION ALL
  SELECT SUM(s.lec+ s.lab +s.pract) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 3 OR s.credits = 3) UNION ALL
  SELECT SUM(s.lec+ s.lab +s.pract) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 4 OR s.credits = 4) UNION ALL
  SELECT SUM(s.lec+ s.lab +s.pract) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 5 OR s.credits = 5) UNION ALL
  SELECT SUM(s.lec+ s.lab +s.pract) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 6 OR s.credits = 6) UNION ALL
  SELECT SUM(s.lec+ s.lab +s.pract) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 7 OR s.credits = 7) UNION ALL
  SELECT SUM(s.lec+ s.lab +s.pract) FROM subjects s
  INNER JOIN partes p ON s.idPart = p.idPart
  INNER JOIN cycles c ON p.idCycle = c.idCycle WHERE c.idTitle = idTitle AND (s.exams = 8 OR s.credits = 8);
END;

